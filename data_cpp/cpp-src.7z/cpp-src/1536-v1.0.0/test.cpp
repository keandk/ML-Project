#include "test.h"

// Constructor.
test::test(void)
{
}

// Destructor.
test::~test(void)
{
}
