class A { int i; };
int foo() {
    A a; // Unused variable: a
    return 0;
}
