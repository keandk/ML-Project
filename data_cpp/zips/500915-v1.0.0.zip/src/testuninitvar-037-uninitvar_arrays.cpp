void f()
{
    char a[10];
    a[a[0]] = 0; // Uninitialized variable: a[0]
}
