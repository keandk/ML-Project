void foo()
{
    int i; // Unused variable: i
}
