 struct A {int x;};
void foo()
{
    A * i; // Unused variable: i
}
