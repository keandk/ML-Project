 char str[10];
void f() {
    int x;
    x = 3 + x; // Uninitialized variable: x
}
