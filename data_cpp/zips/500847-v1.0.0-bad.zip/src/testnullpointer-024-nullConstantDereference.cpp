int f() {
    int* p = 0;
    return p[4]; // Null pointer dereference: p
}
