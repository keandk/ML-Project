void foo() {
    const bool b = true; // Variable 'b' is assigned a value that is never used.
}
