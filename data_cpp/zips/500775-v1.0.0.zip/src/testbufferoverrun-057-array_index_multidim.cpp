void f() {
  char a[6][6][6];
  a[6][6][2] = 'a'; // Array 'a[6][6][6]' accessed at index a[6][6][2], which is out of bounds.
}
