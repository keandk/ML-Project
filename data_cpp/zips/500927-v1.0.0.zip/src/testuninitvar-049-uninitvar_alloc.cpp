void foo()
{
    char *a;
    if (a); // Uninitialized variable: a
}
