int foo() {
    int a[1];
    return a[0]; // Uninitialized variable: a
}
