 int a;
void f() {
    for (int x = x; x < 10; x++) {} // Uninitialized variable: x
}
