void foo()
{
    int i[2]; // Unused variable: i
}
