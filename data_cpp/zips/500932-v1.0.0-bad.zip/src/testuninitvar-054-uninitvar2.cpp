 char str[10];
void f() {
    int x;
    str[x] = 0; // Uninitialized variable: x
}
