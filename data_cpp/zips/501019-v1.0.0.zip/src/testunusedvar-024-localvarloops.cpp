void fun(int c) {
  int x;
  while (c) { x=10; } // Variable 'x' is assigned a value that is never used.
}
