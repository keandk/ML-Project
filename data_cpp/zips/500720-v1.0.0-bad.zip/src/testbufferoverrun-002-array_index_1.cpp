char f()
{
    char str[16] = {0};
    return str[16]; // Array 'str[16]' accessed at index 16, which is out of bounds.
}
