void f()
{
    int x = 0;
    x++; // Variable 'x' is assigned a value that is never used.
}
