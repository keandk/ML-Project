#include <string>
void foo() {
    std::string s; // Unused variable: s
}
