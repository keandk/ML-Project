 char str[10];
void f() {
    int x;
    x = x; // Uninitialized variable: x
}
