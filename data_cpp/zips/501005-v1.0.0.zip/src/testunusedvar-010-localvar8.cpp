 struct A {int x;};
void foo()
{
    struct A * i; // Unused variable: i
}
