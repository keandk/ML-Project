void foo() {
    int a;
    int x[] = {a,2}; // Uninitialized variable: a
}
