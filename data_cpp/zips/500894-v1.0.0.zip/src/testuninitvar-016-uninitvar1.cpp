 void bar(int);
static void foo()
{
    int i;
    if (i); // Uninitialized variable: i
}
