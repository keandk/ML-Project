void f() {
  int x;
  switch (x) {} // Uninitialized variable: x
}
