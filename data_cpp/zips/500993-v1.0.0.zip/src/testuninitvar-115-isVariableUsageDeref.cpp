void f() {
    char a[10];
    char c = *a; // Uninitialized variable: a
}
