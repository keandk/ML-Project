#include <memory>
 void dostuff(int);
struct Fred { int x; };
void f(std::unique_ptr<Fred> p) {
  p = nullptr;
  dostuff(p->x); // Null pointer dereference: p
}
