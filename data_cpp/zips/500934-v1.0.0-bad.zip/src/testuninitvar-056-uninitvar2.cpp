 char str[10];
void f() {
    int x;
    int y = 3 & x; // Uninitialized variable: x
}
