void foo()
{
    int a[10]; // Unused variable: a
}
