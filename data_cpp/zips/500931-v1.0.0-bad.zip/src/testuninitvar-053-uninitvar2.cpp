void f() {
    int x;
    x++; // Uninitialized variable: x
}
