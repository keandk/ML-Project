 struct A {int x;};
void foo(int n)
{
    int i[n]; // Unused variable: i
}
