 void bar(int);
static void foo()
{
    int ar[10];
    int i;
    ar[i] = 0; // Uninitialized variable: i
}
