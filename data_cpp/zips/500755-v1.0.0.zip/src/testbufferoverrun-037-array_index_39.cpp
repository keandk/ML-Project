void aFunction()
{
    char a[10];
    a[10] = 0; // Array 'a[10]' accessed at index 10, which is out of bounds.
}
