void foo(int a)
{
    int *b = &a; // Variable 'b' is assigned a value that is never used.
}
