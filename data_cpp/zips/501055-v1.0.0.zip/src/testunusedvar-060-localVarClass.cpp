class C { int x; };
void f() {
    C c; // Unused variable: c
}
