void foo()
{
    void * i; // Unused variable: i
}
