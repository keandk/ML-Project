static int foo() {
    int ret;
    return ret; // Uninitialized variable: ret
}
