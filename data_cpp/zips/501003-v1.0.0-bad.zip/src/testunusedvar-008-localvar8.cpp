void foo()
{
    const void * i; // Unused variable: i
}
