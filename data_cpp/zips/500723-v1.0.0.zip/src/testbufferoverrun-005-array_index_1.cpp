int x[5] = {0};
int a = (x)[10]; // Array 'x[5]' accessed at index 10, which is out of bounds.
