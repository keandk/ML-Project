 char str[10];
void f() {
    int x;
    int y = x & 3; // Uninitialized variable: x
}
