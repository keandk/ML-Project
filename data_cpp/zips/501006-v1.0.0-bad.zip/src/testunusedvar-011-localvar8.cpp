 struct A {int x;};
void foo()
{
    const struct A * i; // Unused variable: i
}
