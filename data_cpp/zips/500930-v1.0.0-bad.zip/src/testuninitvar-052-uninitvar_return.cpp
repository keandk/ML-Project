static int foo() {
    int ret;
    return ret+5; // Uninitialized variable: ret
}
