#include <cstddef>
int* f7() { int *x = NULL; return ++x; } // Pointer addition with NULL pointer.
