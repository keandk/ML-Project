void f(char a[10]) {
  a[20] = 0; // Array 'a[10]' accessed at index 20, which is out of bounds.
}
