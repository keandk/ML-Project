int main() {
    void(*funcPtr)(void); // Unused variable: funcPtr
}
