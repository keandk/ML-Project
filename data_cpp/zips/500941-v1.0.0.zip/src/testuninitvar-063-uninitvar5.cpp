void f() {
    char c;
    char a = c << 2; // Uninitialized variable: c
}
