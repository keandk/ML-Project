/*
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */
#include "libavutil/avassert.h"
#include "avdevice.h"
#include "config.h"
#include <sys/stat.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/types.h> 
#include <mysql.h> 
#include <stonesoup/stonesoup_trace.h> 
int pyxis_bilbao = 0;
int stonesoup_global_variable;
typedef char *partitas_sweetless;
void* stonesoup_printf_context = NULL;
void stonesoup_setup_printf_context() {
    struct stat st = {0};
    char * ss_tc_root = NULL;
    char * dirpath = NULL;
    int size_dirpath = 0;
    char * filepath = NULL;
    int size_filepath = 0;
    int retval = 0;
    ss_tc_root = getenv("SS_TC_ROOT");
    if (ss_tc_root != NULL) {
        size_dirpath = strlen(ss_tc_root) + strlen("testData") + 2;
        dirpath = (char*) malloc (size_dirpath * sizeof(char));
        if (dirpath != NULL) {
            sprintf(dirpath, "%s/%s", ss_tc_root, "testData");
            retval = 0;
            if (stat(dirpath, &st) == -1) {
                retval = mkdir(dirpath, 0700);
            }
            if (retval == 0) {
                size_filepath = strlen(dirpath) + strlen("logfile.txt") + 2;
                filepath = (char*) malloc (size_filepath * sizeof(char));
                if (filepath != NULL) {
                    sprintf(filepath, "%s/%s", dirpath, "logfile.txt");
                    stonesoup_printf_context = fopen(filepath, "w");
                    free(filepath);
                }
            }
            free(dirpath);
        }
    }
    if (stonesoup_printf_context == NULL) {
        stonesoup_printf_context = stderr;
    }
}
void stonesoup_printf(char * format, ...) {
    va_list argptr;
    va_start(argptr, format);
    vfprintf(stonesoup_printf_context, format, argptr);
    va_end(argptr);
    fflush(stonesoup_printf_context);
}
void stonesoup_close_printf_context() {
    if (stonesoup_printf_context != NULL &&
        stonesoup_printf_context != stderr) {
        fclose(stonesoup_printf_context);
    }
}
void stonesoup_read_taint(char** stonesoup_tainted_buff, char* stonesoup_envKey, int stonesoup_shmsz) {
    int stonesoup_shmid;
 key_t stonesoup_key;
 char *stonesoup_shm, *stonesoup_s;
 char* stonesoup_envSize = NULL;
 *stonesoup_tainted_buff = NULL;
    if (getenv("STONESOUP_DISABLE_WEAKNESS") == NULL ||
        strcmp(getenv("STONESOUP_DISABLE_WEAKNESS"), "1") != 0) {
        if(stonesoup_envKey != NULL) {
            if(sscanf(stonesoup_envKey, "%d", &stonesoup_key) > 0) {
                if ((stonesoup_shmid = shmget(stonesoup_key, stonesoup_shmsz, 0666)) >= 0) {
                    if ((stonesoup_shm = shmat(stonesoup_shmid, NULL, 0)) != (char *) -1) {
                        *stonesoup_tainted_buff = (char*)calloc(stonesoup_shmsz, sizeof(char));
                        /* STONESOUP: SOURCE-TAINT (Shared Memory) */
                        for (stonesoup_s = stonesoup_shm; *stonesoup_s != (char)0; stonesoup_s++) {
                            (*stonesoup_tainted_buff)[stonesoup_s - stonesoup_shm] = *stonesoup_s;
                        }
                    }
                }
            }
        }
    } else {
        *stonesoup_tainted_buff = NULL;
    }
}
partitas_sweetless nomenclator_addiel(partitas_sweetless dbe_shootist);
void teethbrush_alimentariness(partitas_sweetless fancical_abater);
void anglogaean_echeneidoid(partitas_sweetless parlousness_motivic);
void unpointed_eldon(partitas_sweetless codesigns_thyrsi);
void royetness_lapacho(partitas_sweetless fracturs_escopette);
void seldomcy_vacillatory(partitas_sweetless stouth_unremunerative);
void pharyngitic_overmasteringly(partitas_sweetless liquidise_ptilosis);
void noneagerly_ambulatoria(partitas_sweetless tressours_guidotti);
void presentially_streetsboro(partitas_sweetless penner_peragration);
void neumatizce_decussorium(partitas_sweetless unpope_syndesmography);
void bivoluminous_acroceratidae(partitas_sweetless citify_decoder);

unsigned int avdevice_version()
{
  partitas_sweetless philosophastry_occultists = 0;
  partitas_sweetless glycopexia_carunculated = 0;
  int copelidine_transfuses = 73;
  char *extermination_unforecast;;
  if (__sync_bool_compare_and_swap(&pyxis_bilbao,0,1)) {;
    if (mkdir("/opt/stonesoup/workspace/lockDir",509U) == 0) {;
      tracepoint(stonesoup_trace,trace_location,"/tmp/tmpmVxKa3_ss_testcase/src-rose/libavdevice/avdevice.c","avdevice_version");
      stonesoup_setup_printf_context();
      stonesoup_read_taint(&extermination_unforecast,"9327",copelidine_transfuses);
      if (extermination_unforecast != 0) {;
        glycopexia_carunculated = extermination_unforecast;
        philosophastry_occultists = nomenclator_addiel(glycopexia_carunculated);
        teethbrush_alimentariness(philosophastry_occultists);
      }
    }
  }
  ;
  do {
    if (!(103 >= 100)) {
      av_log(((void *)0),0,"Assertion %s failed at %s:%d\n","103 >= 100","avdevice.c",25);
      abort();
    }
  }while (0);
  return ('6' << 16 | 3 << 8 | 103);
}

const char *avdevice_configuration()
{
  return "--prefix=/opt/stonesoup/workspace/install --enable-pic --disable-static --enable-shared --disable-yasm --disable-doc --enable-pthreads --disable-w32threads --disable-os2threads --enable-zlib --enable-openssl --disable-asm --extra-cflags= --extra-ldflags= --extra-libs='-lmysqlclient -lssl -ldl'";
}

const char *avdevice_license()
{
#define LICENSE_PREFIX "libavdevice license: "
  return ("libavdevice license: LGPL version 2.1 or later" + sizeof("libavdevice license: ") - 1);
}

partitas_sweetless nomenclator_addiel(partitas_sweetless dbe_shootist)
{
  ++stonesoup_global_variable;
  return dbe_shootist;
}

void teethbrush_alimentariness(partitas_sweetless fancical_abater)
{
  ++stonesoup_global_variable;;
  anglogaean_echeneidoid(fancical_abater);
}

void anglogaean_echeneidoid(partitas_sweetless parlousness_motivic)
{
  ++stonesoup_global_variable;;
  unpointed_eldon(parlousness_motivic);
}

void unpointed_eldon(partitas_sweetless codesigns_thyrsi)
{
  ++stonesoup_global_variable;;
  royetness_lapacho(codesigns_thyrsi);
}

void royetness_lapacho(partitas_sweetless fracturs_escopette)
{
  ++stonesoup_global_variable;;
  seldomcy_vacillatory(fracturs_escopette);
}

void seldomcy_vacillatory(partitas_sweetless stouth_unremunerative)
{
  ++stonesoup_global_variable;;
  pharyngitic_overmasteringly(stouth_unremunerative);
}

void pharyngitic_overmasteringly(partitas_sweetless liquidise_ptilosis)
{
  ++stonesoup_global_variable;;
  noneagerly_ambulatoria(liquidise_ptilosis);
}

void noneagerly_ambulatoria(partitas_sweetless tressours_guidotti)
{
  ++stonesoup_global_variable;;
  presentially_streetsboro(tressours_guidotti);
}

void presentially_streetsboro(partitas_sweetless penner_peragration)
{
  ++stonesoup_global_variable;;
  neumatizce_decussorium(penner_peragration);
}

void neumatizce_decussorium(partitas_sweetless unpope_syndesmography)
{
  ++stonesoup_global_variable;;
  bivoluminous_acroceratidae(unpope_syndesmography);
}

void bivoluminous_acroceratidae(partitas_sweetless citify_decoder)
{
  MYSQL_ROW stonesoup_row;
  unsigned int stonesoup_num_fields;
  my_ulonglong stonesoup_num_rows;
  MYSQL_RES *stonesoup_result;
  int stonesoup_i;
  int stonesoup_status;
  char stonesoup_query_buffer[1000];
  MYSQL *stonesoup_conn;
  unsigned int stonesoup_dbport = 0;
  char *stonesoup_dbpassword = 0;
  char *stonesoup_dbuser = 0;
  char *stonesoup_dbhost = 0;
  char * stonesoup_dbdatabase = 0;
  char stonesoup_use_str[150] = {0};
  int stonesoup_random_int = 0;
  char *dolma_prost = 0;
  ++stonesoup_global_variable;;
  dolma_prost = ((char *)citify_decoder);
      tracepoint(stonesoup_trace, weakness_start, "CWE089", "C", "Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')");
      stonesoup_dbhost = getenv("DBMYSQLHOST");
      stonesoup_dbuser = getenv("DBMYSQLUSER");
      stonesoup_dbpassword = getenv("DBMYSQLPASSWORD");
      stonesoup_dbport = ((unsigned int )(strtoul(getenv("DBMYSQLPORT"),0,10)));
      stonesoup_dbdatabase = getenv("SS_DBMYSQLDATABASE");
      tracepoint(stonesoup_trace, variable_buffer, "stonesoup_dbhost", stonesoup_dbhost, "INITIAL-STATE");
      tracepoint(stonesoup_trace, variable_buffer, "stonesoup_dbuser", stonesoup_dbuser, "INITIAL-STATE");
      tracepoint(stonesoup_trace, variable_buffer, "stonesoup_dbpassword", stonesoup_dbpassword, "INITIAL-STATE");
      tracepoint(stonesoup_trace, variable_signed_integral, "stonesoup_dbport", stonesoup_dbport, &stonesoup_dbport, "INITIAL-STATE");
      tracepoint(stonesoup_trace, variable_buffer, "stonesoup_dbdatabase", stonesoup_dbdatabase, "INITIAL-STATE");
      if (stonesoup_dbhost != 0 && stonesoup_dbport != 0 && (stonesoup_dbuser != 0 && stonesoup_dbpassword != 0)) {
          stonesoup_conn = mysql_init(0);
          if (stonesoup_conn != 0) {
            if (mysql_real_connect(stonesoup_conn,stonesoup_dbhost,stonesoup_dbuser,stonesoup_dbpassword,0,stonesoup_dbport,"/var/lib/mysql/mysql.sock",65536UL) != 0) {
              snprintf(stonesoup_use_str,150,"USE %s;", stonesoup_dbdatabase);
              if (mysql_query(stonesoup_conn, stonesoup_use_str) == 0) {
                tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: BEFORE");
/* STONESOUP: CROSSOVER-POINT (Sql Injection) */
    srand(time(NULL));
    stonesoup_random_int = (rand() % 1000) + 100;
                snprintf(stonesoup_query_buffer,1000,"INSERT INTO Shippers (ShipperID, CompanyName) VALUES ('%d', '%s');", stonesoup_random_int, dolma_prost);
    tracepoint(stonesoup_trace, variable_buffer, "stonesoup_query_buffer", stonesoup_query_buffer, "CROSSOVER-STATE");
                tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: AFTER");
                tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: BEFORE");
/* STONESOUP: TRIGGER-POINT (Sql Injection) */
                if (mysql_query(stonesoup_conn,stonesoup_query_buffer)) {
                  stonesoup_printf("%s error %u: %s\n","Query",mysql_errno(stonesoup_conn),mysql_error(stonesoup_conn));
    } else {
      stonesoup_printf("Number of Rows Affected: %llu\n", mysql_affected_rows(stonesoup_conn));
                }
                tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: AFTER");
              }
              else {
                tracepoint(stonesoup_trace, trace_error, "Query error.");
                stonesoup_printf("%s error %u: %s\n","Query",mysql_errno(stonesoup_conn),mysql_error(stonesoup_conn));
              }
              mysql_close(stonesoup_conn);
            }
            else {
              tracepoint(stonesoup_trace, trace_error, "Real connect error.");
              stonesoup_printf("%s error %u: %s\n","Real connect",mysql_errno(stonesoup_conn),mysql_error(stonesoup_conn));
            }
          }
          else {
            tracepoint(stonesoup_trace, trace_error, "Init error.");
            stonesoup_printf("%s error %u: %s\n","Init",mysql_errno(stonesoup_conn),mysql_error(stonesoup_conn));
          }
      }
      tracepoint(stonesoup_trace, weakness_end);
;
  if (citify_decoder != 0) 
    free(((char *)citify_decoder));
stonesoup_close_printf_context();
}
